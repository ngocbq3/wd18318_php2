<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <nav>
        <a href="?ctl=home">Trang chủ</a>
        <a href="?ctl=contact">Liên hệ</a>
        <a href="?ctl=product">Sản phẩm</a>
        <a href="?ctl=about">Giới thiệu</a>
    </nav>