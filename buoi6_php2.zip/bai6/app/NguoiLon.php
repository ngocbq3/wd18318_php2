<?php

namespace App;

class NguoiLon extends ConNguoi
{
}
